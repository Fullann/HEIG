import calculator.JCalculator;

public class Main
{
  public static void main(String ... args) {
    new JCalculator();
  }
}
