package calculator;

public interface Operator {
  void execute(State state);
}
